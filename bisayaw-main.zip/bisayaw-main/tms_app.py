import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import time
import threading
import serial
import sys
import subprocess
from serial.tools import list_ports
# Cross-platform beep support
try:
    import winsound
    def beep(freq, dur):
        try:
            winsound.Beep(freq, dur)
        except Exception:
            pass
except Exception:
    def beep(freq, dur):
        # Reliable macOS beep via osascript/afplay; fallback to Tk bell or terminal bell
        try:
            if sys.platform == "darwin":
                try:
                    count = max(1, min(5, int(round(dur / 200.0))))
                    subprocess.Popen(["osascript", "-e", f"beep {count}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except Exception:
                    try:
                        subprocess.Popen(["afplay", "/System/Library/Sounds/Pop.aiff"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        return
                    except Exception:
                        pass
            # Try Tkinter bell if available; otherwise use terminal bell
            root.bell()  # type: ignore[name-defined]
        except Exception:
            try:
                print("\a", end="", flush=True)
            except Exception:
                pass


def guess_best_port(port_list):
    low = [p.lower() for p in port_list]
    mac = [p for p, l in zip(port_list, low) if "/cu." in l and any(k in l for k in ("usbmodem", "usbserial", "wchusbserial"))]
    if mac:
        return mac[0]
    usb = [p for p, l in zip(port_list, low) if any(k in l for k in ("usbmodem", "usbserial", "wchusbserial"))]
    if usb:
        return usb[0]
    if sys.platform.startswith("win") and any(p.upper() == "COM3" for p in port_list):
        return "COM3"
    return port_list[0] if port_list else None


def select_port_gui(port_list, initial):
    sel_root = tk.Tk()
    sel_root.title("Select Serial Port")
    sel_root.geometry("360x160")

    tk.Label(sel_root, text="Select Arduino serial port:").pack(padx=12, pady=10)

    var = tk.StringVar(value=initial if initial in port_list else (port_list[0] if port_list else ""))
    opt = tk.OptionMenu(sel_root, var, *port_list)
    opt.pack(padx=12, pady=6)

    selection = {"value": None}

    btn_frame = tk.Frame(sel_root)
    btn_frame.pack(pady=12)

    def on_connect():
        selection["value"] = var.get()
        sel_root.destroy()

    def on_cancel():
        selection["value"] = None
        sel_root.destroy()

    tk.Button(btn_frame, text="Connect", width=10, command=on_connect).pack(side="left", padx=8)
    tk.Button(btn_frame, text="Cancel", width=10, command=on_cancel).pack(side="left", padx=8)

    sel_root.mainloop()
    return selection["value"]


def run_tms_app():
    # Detect available serial ports
    ports = [p.device for p in list_ports.comports()]
    if not ports:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("🚦 Traffic Light Controller", "No serial ports found. Please connect your Arduino and try again.")
        r.destroy()
        return

    # Auto-select port (no prompt)
    selected_port = guess_best_port(ports) or ports[0]

    try:
        arduino = serial.Serial(port=selected_port, baudrate=9600, timeout=1)
    except Exception as e:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("🚦 Traffic Light Controller", f"Serial Error: {e}")
        r.destroy()
        return

    time.sleep(2)
    try:
        arduino.reset_input_buffer()
    except Exception:
        pass

    running = False
    paused = False
    current_color = "OFF"
    countdown_time = 0
    cycle_times = {"GREEN": 5, "YELLOW": 2, "RED": 5}

    root = tk.Tk()
    root.title("🚦 Traffic Light Controller")

    # Themed styles for colored buttons (works on macOS when using 'clam' theme)
    style = ttk.Style(root)
    try:
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass
    style.configure("Primary.TButton", background="#1E90FF", foreground="white", padding=(8, 6))
    style.map("Primary.TButton", background=[("active", "#187bcd"), ("disabled", "#7fb6e6")])
    style.configure("Warning.TButton", background="#FFA500", foreground="white", padding=(8, 6))
    style.map("Warning.TButton", background=[("active", "#ff8c00")])
    style.configure("Danger.TButton", background="#8B0000", foreground="white", padding=(8, 6))
    style.map("Danger.TButton", background=[("active", "#a40000"), ("disabled", "#a44")])

    # Ensure all UI updates happen on the main thread (needed on macOS/Tkinter)
    def ui_call(fn, *args, **kwargs):
        try:
            root.after(0, lambda: fn(*args, **kwargs))
        except Exception:
            pass

    frame = tk.Frame(root, padx=20, pady=20)
    frame.pack()

    tk.Label(frame, text="Traffic Light Simulation", font=("Arial", 16, "bold")).grid(
        row=0, column=0, columnspan=3, pady=10
    )

    canvas = tk.Canvas(frame, width=120, height=300, bg="black")
    canvas.grid(row=1, column=1, rowspan=3, padx=20, pady=10)

    light_red = canvas.create_oval(20, 20, 100, 100, fill="gray")
    light_yellow = canvas.create_oval(20, 110, 100, 190, fill="gray")
    light_green = canvas.create_oval(20, 200, 100, 280, fill="gray")

    def update_traffic_light(color):
        def _do_update():
            colors = {"RED": light_red, "YELLOW": light_yellow, "GREEN": light_green}
            for light in (light_red, light_yellow, light_green):
                canvas.itemconfig(light, fill="gray")
            sel = colors.get(color)
            if sel:
                canvas.itemconfig(sel, fill=color.lower())
            freq = {"RED": 500, "YELLOW": 800, "GREEN": 1000}.get(color)
            if freq:
                beep(freq, 300)
        ui_call(_do_update)

    def update_status(text):
        ui_call(status_label.config, text=text)

    def set_timer_text(text):
        ui_call(timer_label.config, text=text)

    def send_command(cmd):
        nonlocal current_color, countdown_time
        try:
            arduino.write(cmd.encode())
        except Exception as e:
            update_status(f"Serial write failed: {e}")
            return

        time.sleep(0.1)
        line = arduino.readline().decode(errors='ignore').strip()
        response = line if line else "<no response>"
        print("Arduino:", response)

        resp_upper = response.upper()
        if "RED" in resp_upper:
            current_color = "RED"
        elif "YELLOW" in resp_upper:
            current_color = "YELLOW"
        elif "GREEN" in resp_upper:
            current_color = "GREEN"
        elif cmd == "O":
            current_color = "OFF"

        countdown_time = cycle_times.get(current_color, 5)
        update_traffic_light(current_color)
        update_status(f"Arduino: {response}")

    def toggle_start_pause():
        nonlocal running, paused
        if not running:
            running, paused = True, False
            btn_toggle.config(text="⏸ PAUSE", style="Warning.TButton")
            threading.Thread(target=auto_loop, daemon=True).start()
        else:
            paused = not paused
            btn_toggle.config(
                text=("▶ RESUME" if paused else "⏸ PAUSE"),
                style=("Primary.TButton" if paused else "Warning.TButton"),
            )
            update_status(f"{'Paused' if paused else 'Resumed'} at {current_color}")

    def stop_auto():
        nonlocal running, paused
        running = paused = False
        send_command("O")
        btn_toggle.config(text="▶ START", style="Primary.TButton")
        update_status("Stopped - Lights OFF")
        set_timer_text("⏳ Time left: --s")
        update_traffic_light("OFF")

    def next_state():
        return {"RED": "G", "GREEN": "Y", "YELLOW": "R"}.get(current_color, "R")

    def auto_loop():
        nonlocal countdown_time
        if current_color == "OFF":
            send_command("R")
        while running:
            for t in range(countdown_time, 0, -1):
                if not running:
                    return
                while paused and running:
                    time.sleep(0.5)
                set_timer_text(f"⏳ Time left: {t}s")
                update_status(f"Current State: {current_color}")
                time.sleep(1)
            if running and not paused:
                send_command(next_state())
                countdown_time = cycle_times.get(current_color, 5)

    btn_toggle = ttk.Button(frame, text="▶ START", style="Primary.TButton", width=12,
                           command=toggle_start_pause)
    btn_toggle.grid(row=1, column=0, padx=5, pady=5)

    btn_stop = ttk.Button(frame, text="⏹ STOP", style="Danger.TButton", width=12,
                         command=stop_auto)
    btn_stop.grid(row=2, column=0, padx=5, pady=5)

    timer_label = tk.Label(frame, text="⏳ Time left: --s", font=("Arial", 14))
    timer_label.grid(row=4, column=0, columnspan=3, pady=10)

    status_label = tk.Label(frame, text="Arduino: Waiting for command...", font=("Arial", 12))
    status_label.grid(row=5, column=0, columnspan=3, pady=10)

    root.mainloop()

    # Auto-select port (no prompt)
    selected_port = guess_best_port(ports) or ports[0]
