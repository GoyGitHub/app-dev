import menu

if __name__ == "__main__":
   menu.open_main_menu()
