# login.py
import tkinter as tk
from tkinter import messagebox, ttk
import menu

DEFAULT_USERNAME = "admin"
DEFAULT_PASSWORD = "pass"

def open_login():
    root = tk.Tk()
    root.title("Login")
    root.geometry("350x240")
    root.configure(bg="#ADD8E6")  # light blue background

    # use ttk with clam theme for colored widgets on macOS
    style = ttk.Style(root)
    try:
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass
    style.configure("Login.TButton", background="#87CEFA", foreground="black", padding=(8, 6))
    style.map("Login.TButton", background=[("active", "#5AB0F6")])
    style.configure("Login.TEntry", fieldbackground="white")

    tk.Label(root, text="LOGIN", font=("Cooper Black", 20),
             fg="black", bg="#ADD8E6").pack(pady=10)

    tk.Label(root, text="Username:", fg="black", bg="#ADD8E6").pack(pady=5)
    username_entry = ttk.Entry(root, width=25, style="Login.TEntry")
    username_entry.pack()

    tk.Label(root, text="Password:", fg="black", bg="#ADD8E6").pack(pady=5)
    password_entry = ttk.Entry(root, show="*", width=25, style="Login.TEntry")
    password_entry.pack()

    def attempt_login():
        username = username_entry.get()
        password = password_entry.get()
        if username == DEFAULT_USERNAME and password == DEFAULT_PASSWORD:
            root.destroy()
            menu.open_main_menu()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    ttk.Button(root, text="Login", style="Login.TButton",
               command=attempt_login).pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    open_login()
