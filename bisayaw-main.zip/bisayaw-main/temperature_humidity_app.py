import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import time
import threading
import serial
import sys
import subprocess
from serial.tools import list_ports

# Cross-platform beep support
try:
    import winsound
    def beep(freq, dur):
        try:
            winsound.Beep(freq, dur)
        except Exception:
            pass
except Exception:
    def beep(freq, dur):
        # Reliable macOS beep via osascript/afplay; fallback to Tk bell or terminal bell
        try:
            if sys.platform == "darwin":
                try:
                    count = max(1, min(5, int(round(dur / 200.0))))
                    subprocess.Popen(["osascript", "-e", f"beep {count}"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except Exception:
                    try:
                        subprocess.Popen(["afplay", "/System/Library/Sounds/Pop.aiff"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        return
                    except Exception:
                        pass
            # Try Tkinter bell if available; otherwise use terminal bell
            root.bell()  # type: ignore[name-defined]
        except Exception:
            try:
                print("\a", end="", flush=True)
            except Exception:
                pass


def guess_best_port(port_list):
    low = [p.lower() for p in port_list]
    mac = [p for p, l in zip(port_list, low) if "/cu." in l and any(k in l for k in ("usbmodem", "usbserial", "wchusbserial"))]
    if mac:
        return mac[0]
    usb = [p for p, l in zip(port_list, low) if any(k in l for k in ("usbmodem", "usbserial", "wchusbserial"))]
    if usb:
        return usb[0]
    if sys.platform.startswith("win") and any(p.upper() == "COM3" for p in port_list):
        return "COM3"
    return port_list[0] if port_list else None


def select_port_gui(port_list, initial):
    sel_root = tk.Tk()
    sel_root.title("Select Serial Port")
    sel_root.geometry("360x160")

    tk.Label(sel_root, text="Select Arduino serial port:").pack(padx=12, pady=10)

    var = tk.StringVar(value=initial if initial in port_list else (port_list[0] if port_list else ""))
    opt = tk.OptionMenu(sel_root, var, *port_list)
    opt.pack(padx=12, pady=6)

    selection = {"value": None}

    btn_frame = tk.Frame(sel_root)
    btn_frame.pack(pady=12)

    def on_connect():
        selection["value"] = var.get()
        sel_root.destroy()

    def on_cancel():
        selection["value"] = None
        sel_root.destroy()

    tk.Button(btn_frame, text="Connect", width=10, command=on_connect).pack(side="left", padx=8)
    tk.Button(btn_frame, text="Cancel", width=10, command=on_cancel).pack(side="left", padx=8)

    sel_root.mainloop()
    return selection["value"]


def run_temperature_humidity_app():
    # Detect available serial ports
    ports = [p.device for p in list_ports.comports()]
    if not ports:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("🌡️ Temperature & Humidity Monitor", "No serial ports found. Please connect your Arduino and try again.")
        r.destroy()
        return

    # Auto-select port (no prompt)
    selected_port = guess_best_port(ports) or ports[0]

    try:
        arduino = serial.Serial(port=selected_port, baudrate=9600, timeout=1)
    except Exception as e:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("🌡️ Temperature & Humidity Monitor", f"Serial Error: {e}")
        r.destroy()
        return

    time.sleep(2)
    try:
        arduino.reset_input_buffer()
    except Exception:
        pass

    running = True
    paused = False
    temperature = 0
    humidity = 0
    alert_active = False
    alert_threshold = 32  # Default alert threshold
    beep_thread = None
    stop_beeping = False

    root = tk.Tk()
    root.title("🌡️ Temperature & Humidity Monitor")

    # Themed styles for buttons
    style = ttk.Style(root)
    try:
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass
    style.configure("Primary.TButton", background="#1E90FF", foreground="white", padding=(8, 6))
    style.map("Primary.TButton", background=[("active", "#187bcd"), ("disabled", "#7fb6e6")])
    style.configure("Warning.TButton", background="#FFA500", foreground="white", padding=(8, 6))
    style.map("Warning.TButton", background=[("active", "#ff8c00")])
    style.configure("Danger.TButton", background="#8B0000", foreground="white", padding=(8, 6))
    style.map("Danger.TButton", background=[("active", "#a40000"), ("disabled", "#a44")])

    # Ensure all UI updates happen on the main thread (needed on macOS/Tkinter)
    def ui_call(fn, *args, **kwargs):
        try:
            root.after(0, lambda: fn(*args, **kwargs))
        except Exception:
            pass

    frame = tk.Frame(root, padx=20, pady=20)
    frame.pack()

    tk.Label(frame, text="Temperature & Humidity Monitor", font=("Arial", 16, "bold")).grid(
        row=0, column=0, columnspan=3, pady=10
    )

    # Create temperature and humidity display
    temp_frame = tk.Frame(frame, bd=2, relief=tk.RIDGE, padx=15, pady=15, bg="#f0f0f0")
    temp_frame.grid(row=1, column=0, columnspan=3, padx=10, pady=10, sticky="ew")

    temp_label = tk.Label(temp_frame, text="Temperature:", font=("Arial", 14), bg="#f0f0f0")
    temp_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
    
    temp_value = tk.Label(temp_frame, text="-- °C", font=("Arial", 24, "bold"), fg="#FF5733", bg="#f0f0f0")
    temp_value.grid(row=0, column=1, padx=10, pady=5)

    humid_label = tk.Label(temp_frame, text="Humidity:", font=("Arial", 14), bg="#f0f0f0")
    humid_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
    
    humid_value = tk.Label(temp_frame, text="-- %", font=("Arial", 24, "bold"), fg="#3366FF", bg="#f0f0f0")
    humid_value.grid(row=1, column=1, padx=10, pady=5)

    # Alert threshold setting
    threshold_frame = tk.Frame(frame, bd=2, relief=tk.RIDGE, padx=15, pady=15)
    threshold_frame.grid(row=2, column=0, columnspan=3, padx=10, pady=10, sticky="ew")
    
    tk.Label(threshold_frame, text="Temperature Alert Threshold:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
    
    threshold_var = tk.StringVar(value=str(alert_threshold))
    threshold_entry = tk.Entry(threshold_frame, textvariable=threshold_var, width=5)
    threshold_entry.grid(row=0, column=1, padx=5, pady=5)
    
    tk.Label(threshold_frame, text="°C").grid(row=0, column=2, padx=5, pady=5, sticky="w")
    
    def update_threshold():
        nonlocal alert_threshold
        try:
            new_threshold = float(threshold_var.get())
            alert_threshold = new_threshold
            update_status(f"Alert threshold updated to {alert_threshold}°C")
        except ValueError:
            update_status("Invalid threshold value")
    
    ttk.Button(threshold_frame, text="Update", style="Primary.TButton", 
              command=update_threshold).grid(row=0, column=3, padx=10, pady=5)

    # Alert status display
    alert_label = tk.Label(frame, text="NORMAL", font=("Arial", 16, "bold"), fg="green")
    alert_label.grid(row=3, column=0, columnspan=3, pady=10)

    def continuous_beeping():
        nonlocal stop_beeping
        stop_beeping = False
        voice_counter = 0
        while alert_active and not stop_beeping and running:
            if not paused:
                # Use macOS system sounds for continuous beeping
                if sys.platform == "darwin":
                    try:
                        # Play sound alert
                        subprocess.Popen(["afplay", "/System/Library/Sounds/Ping.aiff"], 
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        
                        # Play voice alert every 3 beeps
                        voice_counter += 1
                        if voice_counter >= 3:
                            subprocess.Popen(["say", "Warning temperature high"],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                            voice_counter = 0
                    except Exception:
                        beep(800, 300)  # Fallback to original beep
                else:
                    beep(800, 300)  # Use original beep for non-macOS
            time.sleep(1.5)  # Longer pause to allow voice to complete

    def update_alert_status(is_alert):
        nonlocal alert_active, beep_thread, stop_beeping
        
        # If status is changing
        if is_alert != alert_active:
            alert_active = is_alert
            
            if is_alert:
                ui_call(alert_label.config, text="⚠️ HIGH TEMPERATURE ALERT ⚠️", fg="red")
                
                # Initial alert sound
                if sys.platform == "darwin":
                    try:
                        # Play a system sound
                        subprocess.Popen(["afplay", "/System/Library/Sounds/Glass.aiff"], 
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        # Optional voice alert
                        subprocess.Popen(["say", "Warning temperature high"],
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    except Exception:
                        beep(800, 500)  # Fallback to original beep
                else:
                    beep(800, 500)  # Use original beep for non-macOS
                
                # Start continuous beeping in a separate thread
                stop_beeping = True  # Stop any existing beeping thread
                time.sleep(0.2)  # Give time for existing thread to stop
                beep_thread = threading.Thread(target=continuous_beeping, daemon=True)
                beep_thread.start()
                
            else:
                ui_call(alert_label.config, text="NORMAL", fg="green")
                # Stop the beeping
                stop_beeping = True

    def update_temperature_display(temp, humid):
        ui_call(temp_value.config, text=f"{temp} °C")
        ui_call(humid_value.config, text=f"{humid} %")
        
        # Check for temperature alert
        if temp >= alert_threshold and not alert_active:
            update_alert_status(True)
        elif temp < alert_threshold and alert_active:
            update_alert_status(False)

    def update_status(text):
        ui_call(status_label.config, text=text)

    def toggle_pause():
        nonlocal paused
        paused = not paused
        btn_pause.config(
            text=("▶ RESUME" if paused else "⏸ PAUSE"),
            style=("Primary.TButton" if paused else "Warning.TButton"),
        )
        update_status(f"{'Paused' if paused else 'Resumed'} monitoring")

    def stop_monitoring():
        nonlocal running
        running = False
        root.destroy()

    # Control buttons
    btn_frame = tk.Frame(frame)
    btn_frame.grid(row=4, column=0, columnspan=3, pady=10)

    btn_pause = ttk.Button(btn_frame, text="⏸ PAUSE", style="Warning.TButton", width=12,
                          command=toggle_pause)
    btn_pause.pack(side="left", padx=10)

    btn_stop = ttk.Button(btn_frame, text="⏹ STOP", style="Danger.TButton", width=12,
                         command=stop_monitoring)
    btn_stop.pack(side="left", padx=10)

    status_label = tk.Label(frame, text="Connected to Arduino. Monitoring...", font=("Arial", 12))
    status_label.grid(row=5, column=0, columnspan=3, pady=10)

    # Function to read data from Arduino
    def read_arduino_data():
        nonlocal temperature, humidity, running
        
        while running:
            if not paused:
                try:
                    if arduino.in_waiting > 0:
                        line = arduino.readline().decode(errors='ignore').strip()
                        print("Arduino:", line)
                        
                        # Parse temperature and humidity from Arduino output
                        if "Humidity:" in line and "Temp:" in line:
                            parts = line.split()
                            for i, part in enumerate(parts):
                                if part == "Humidity:":
                                    try:
                                        humidity = float(parts[i+1])
                                    except (ValueError, IndexError):
                                        pass
                                elif part == "Temp:":
                                    try:
                                        temperature = float(parts[i+1])
                                    except (ValueError, IndexError):
                                        pass
                            
                            update_temperature_display(temperature, humidity)
                            update_status(f"Updated: Temp {temperature}°C, Humidity {humidity}%")
                except Exception as e:
                    update_status(f"Error reading data: {e}")
            
            time.sleep(0.5)

    # Start the data reading thread
    threading.Thread(target=read_arduino_data, daemon=True).start()

    root.mainloop()

    # Clean up
    try:
        arduino.close()
    except Exception:
        pass