# menu.py
import tkinter as tk
from tkinter import ttk
import tms_app   # ✅ import traffic light system
import temperature_humidity_app  # ✅ import temperature & humidity app


def open_tms_app(prev_window):
   prev_window.destroy()
   tms_app.run_tms_app()


def open_temperature_humidity_app(prev_window):
   prev_window.destroy()
   temperature_humidity_app.run_temperature_humidity_app()


def open_main_menu():
   menu_window = tk.Tk()
   menu_window.title("Main Menu")
   menu_window.geometry("400x600")
   menu_window.configure(bg="#ADD8E6")  # light blue background

   # Use ttk with a light-blue button style (works on macOS)
   style = ttk.Style(menu_window)
   try:
       if "clam" in style.theme_names():
           style.theme_use("clam")
   except Exception:
       pass
   style.configure("Menu.TButton", background="#87CEFA", foreground="black", padding=(10, 8))
   style.map("Menu.TButton", background=[("active", "#5AB0F6")])

   tk.Label(menu_window, text="MAIN MENU", font=("Cooper Black", 24),
            fg="black", bg="#ADD8E6").pack(pady=30)

   buttons = [
       ("TMS APPLICATION", lambda: open_tms_app(menu_window)),
       ("HUMIDITY & TEMPERATURE", lambda: open_temperature_humidity_app(menu_window)),
       ("LOCK / UNLOCK SYSTEM", None),
       ("ITEM DETECTOR SYSTEM", None),
       ("DISTANCE MEASURE SYSTEM", None)
   ]

   for text, command in buttons:
       ttk.Button(menu_window, text=text, style="Menu.TButton",
                  width=25, command=command).pack(pady=12)

   menu_window.mainloop()
