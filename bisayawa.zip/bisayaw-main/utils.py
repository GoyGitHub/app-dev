# utils.py
def safe_destroy(win):
    """Safely destroy a Tkinter/CustomTkinter window by canceling after() callbacks first."""
    try:
        for job in win.tk.call('after', 'info'):
            try:
                win.after_cancel(job)
            except Exception:
                pass
        win.destroy()
    except Exception:
        pass
