import customtkinter as ctk
from tkinter import messagebox
import auth   # ✅ use global authorization flag

# ======= DEFAULT CREDENTIALS =======
DEFAULT_USERNAME = "admin"
DEFAULT_PASSWORD = "1234"

# ======= LOGIN WINDOW =======
def open_login():
    """Open the redesigned login window with customtkinter UI."""

    def attempt_login():
        """Validate username and password."""
        username = username_entry.get()
        password = password_entry.get()

        if username == DEFAULT_USERNAME and password == DEFAULT_PASSWORD:
            auth.AUTHORIZED = True     # ✅ mark as logged in
            root.destroy()             # Close login window
            import menu                # Local import avoids circular issue
            menu.open_main_menu()      # Open main menu
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

    def cancel_login():
        """Close the application."""
        root.destroy()

    # ======= WINDOW SETUP =======
    root = ctk.CTk()
    root.title("Traffic Light Monitoring System - Login")
    root.geometry("500x280")
    root.configure(fg_color="#1a1a1a")  # Dark background

    # ======= CENTER FRAME =======
    frame = ctk.CTkFrame(root, width=350, height=220, corner_radius=15, fg_color="#2e2e2e")
    frame.place(relx=0.5, rely=0.5, anchor="center")

    # ======= TITLE =======
    ctk.CTkLabel(frame, text="LOGIN", font=("Cooper Black", 22), text_color="white").grid(
        row=0, column=0, columnspan=3, pady=(15, 20)
    )

    # ======= USERNAME =======
    ctk.CTkLabel(frame, text="Username", font=("Arial", 13), text_color="white").grid(
        row=1, column=0, padx=10, pady=10, sticky="e"
    )
    username_entry = ctk.CTkEntry(frame, width=220, font=("Arial", 13))
    username_entry.grid(row=1, column=1, columnspan=2, padx=10, pady=10)

    # ======= PASSWORD =======
    ctk.CTkLabel(frame, text="Password", font=("Arial", 13), text_color="white").grid(
        row=2, column=0, padx=10, pady=10, sticky="e"
    )
    password_entry = ctk.CTkEntry(frame, width=220, font=("Arial", 13), show="*")
    password_entry.grid(row=2, column=1, columnspan=2, padx=10, pady=10)

    # ======= BUTTONS =======
    ctk.CTkButton(frame, text="Login", font=("Arial", 13), width=100,
                  fg_color="green", hover_color="#006400", corner_radius=10,
                  command=attempt_login).grid(row=3, column=1, pady=20)

    ctk.CTkButton(frame, text="Cancel", font=("Arial", 13), width=100,
                  fg_color="red", hover_color="#8B0000", corner_radius=10,
                  command=cancel_login).grid(row=3, column=2, pady=20)

    root.mainloop()


# ======= RUN LOGIN =======
if __name__ == "__main__":
    open_login()
