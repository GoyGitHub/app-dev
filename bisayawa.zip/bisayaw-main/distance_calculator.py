import customtkinter as ctk
from tkinter import messagebox, filedialog
import serial
import serial.tools.list_ports
import threading
import time
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import csv
import statistics
import winsound
import os
import menu
import auth
from utils import safe_destroy

# ------------------------------
# Arduino Connection
# ------------------------------
arduino = None
running = False
data_buffer = []
save_counter = 1
last_beep_time = 0   # ✅ prevent spam
last_graph_update = 0


def connect_arduino():
    global arduino, running
    try:
        port = port_select.get()
        arduino = serial.Serial(port, 9600, timeout=1)
        running = True
        status_var.set(f"✅ Connected to {port}")
        threading.Thread(target=read_data, daemon=True).start()
    except Exception as e:
        messagebox.showerror("Connection Error", str(e))
        status_var.set("❌ Connection failed")


def disconnect_arduino():
    global running, arduino
    running = False
    if arduino and arduino.is_open:
        arduino.close()
    status_var.set("❌ Disconnected")


def read_data():
    global running
    while running and arduino:
        try:
            line = arduino.readline().decode(errors="ignore").strip()
            if line:
                try:
                    value_cm = float(line)  # ✅ Arduino sends just the number
                    update_display(value_cm)
                except ValueError:
                    print(f"Skipped invalid data: {line}")
        except:
            pass


def update_display(cm):
    global last_graph_update

    inches = cm / 2.54
    distance_cm_var.set(f"{cm:.2f} cm")
    distance_in_var.set(f"{inches:.2f} inch")
    check_threshold(cm)

    data_buffer.append(cm)
    if len(data_buffer) > 200:
        data_buffer.pop(0)

    # ✅ update graph once per second
    if time.time() - last_graph_update > 1:
        update_graph()
        last_graph_update = time.time()


def update_graph():
    ax.clear()
    ax.plot(data_buffer, marker='o', color='cyan')
    ax.set_title("Distance over Time", color="white", fontname="Segoe UI")
    ax.set_ylabel("cm", color="white", fontname="Segoe UI")
    ax.set_xlabel("Readings", color="white", fontname="Segoe UI")
    ax.grid(True)
    fig.patch.set_facecolor("#1a1a1a")
    ax.set_facecolor("#2e2e2e")
    for spine in ax.spines.values():
        spine.set_color("white")
    ax.tick_params(colors="white")
    canvas.draw_idle()


def check_threshold(cm):
    global last_beep_time
    try:
        min_val = float(min_entry.get())
        max_val = float(max_entry.get())
    except:
        return

    if cm < min_val or cm > max_val:
        distance_label.configure(text_color="red")
        warning_label.configure(
            text="⚠ Object too close!" if cm < min_val else "⚠ Out of range!"
        )
        root.bell()

        # ✅ Only speed changes (pitch fixed at 1000 Hz)
        if cm > 10:
            interval = 1.0   # slow beep
        elif cm > 6:
            interval = 0.5   # medium
        elif cm > 4:
            interval = 0.25  # fast
        elif cm > 2:
            interval = 0.1   # very fast
        else:
            interval = 0.05  # almost continuous

        if time.time() - last_beep_time > interval:
            last_beep_time = time.time()
            threading.Thread(target=beep_warning, daemon=True).start()
    else:
        distance_label.configure(text_color="cyan")
        warning_label.configure(text="")  # clear warning


def beep_warning():
    """Fixed pitch, only speed varies"""
    try:
        winsound.Beep(1000, 150)  # 1000 Hz, 150 ms
    except Exception as e:
        print("Beep error:", e)


def save_data():
    global save_counter
    if not data_buffer:
        messagebox.showwarning("Warning", "No data to save yet!")
        return
    folder_path = filedialog.askdirectory(title="Select Folder to Save CSV")
    if not folder_path:
        return
    while True:
        file_path = os.path.join(folder_path, f"distance_data_{save_counter}.csv")
        if not os.path.exists(file_path):
            break
        save_counter += 1
    try:
        # ✅ Only take last 100 readings
        limited_data = data_buffer[-100:]

        with open(file_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Reading", "Distance (cm)", "Distance (inch)"])
            for i, val in enumerate(limited_data, start=1):
                writer.writerow([i, f"{val:.2f}", f"{val/2.54:.2f}"])
            writer.writerow([])
            writer.writerow(["Session Summary"])
            writer.writerow(["Min", f"{min(limited_data):.2f} cm", f"{min(limited_data)/2.54:.2f} in"])
            writer.writerow(["Max", f"{max(limited_data):.2f} cm", f"{max(limited_data)/2.54:.2f} in"])
            writer.writerow(["Average", f"{statistics.mean(limited_data):.2f} cm", f"{statistics.mean(limited_data)/2.54:.2f} in"])
        messagebox.showinfo("Saved", f"Data saved as:\n{file_path}")
        status_var.set(f"✅ Data saved (last 100 readings): distance_data_{save_counter}.csv")
        save_counter += 1
    except PermissionError:
        messagebox.showerror("Permission Denied", f"Cannot write to {file_path}. Try a different folder.")
        status_var.set("❌ Save failed - permission denied")



def refresh_graph():
    global data_buffer, save_counter
    data_buffer = []
    save_counter = 1
    update_graph()
    status_var.set("🔄 Graph cleared, save counter reset.")


# ------------------------------
# GUI
# ------------------------------
def run_distance_calculator():
    global root, port_select, distance_cm_var, distance_in_var
    global distance_label, status_var, min_entry, max_entry, fig, ax, canvas, warning_label

    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    root = ctk.CTk()
    root.title("📏 Ultrasonic Distance Calculator")
    root.geometry("800x700")

    # Back Button
    def go_back():
        safe_destroy(root)
        menu.open_main_menu()

    ctk.CTkButton(root, text="← Back",
                  fg_color="#00BFFF", hover_color="#009ACD",
                  corner_radius=12, width=80, height=35,
                  font=("Segoe UI", 14, "bold"),
                  command=go_back).place(x=15, y=15)

    ctk.CTkLabel(root, text="📏 Distance Measurement System",
                 font=("Segoe UI", 26, "bold"), text_color="white").pack(pady=(50, 15))

    # Display Frame
    display_frame = ctk.CTkFrame(root, corner_radius=15, fg_color="#2e2e2e")
    display_frame.pack(pady=10, padx=20, fill="x")

    distance_cm_var = ctk.StringVar(value="0.0 cm")
    distance_in_var = ctk.StringVar(value="0.0 inch")

    ctk.CTkLabel(display_frame, text="Distance (cm):",
                 font=("Segoe UI", 18), text_color="white").grid(row=0, column=0, padx=10, pady=10, sticky="w")
    distance_label = ctk.CTkLabel(display_frame, textvariable=distance_cm_var,
                                  font=("Segoe UI", 36, "bold"), text_color="cyan")
    distance_label.grid(row=0, column=1, padx=10, pady=10)

    ctk.CTkLabel(display_frame, text="Distance (inch):",
                 font=("Segoe UI", 18), text_color="white").grid(row=1, column=0, padx=10, pady=10, sticky="w")
    ctk.CTkLabel(display_frame, textvariable=distance_in_var,
                 font=("Segoe UI", 36, "bold"), text_color="green").grid(row=1, column=1, padx=10, pady=10)

    # ⚠ Warning Label
    warning_label = ctk.CTkLabel(root, text="", font=("Segoe UI", 28, "bold"), text_color="red")
    warning_label.pack(pady=10)

    # Port Frame
    port_frame = ctk.CTkFrame(root, corner_radius=15, fg_color="#2e2e2e")
    port_frame.pack(pady=10, padx=20, fill="x")

    ports = [port.device for port in serial.tools.list_ports.comports()]
    port_select = ctk.CTkComboBox(port_frame, values=ports, width=200, font=("Segoe UI", 14))
    if ports:
        port_select.set(ports[0])
    port_select.grid(row=0, column=0, padx=10, pady=10)

    ctk.CTkButton(port_frame, text="Connect", fg_color="#00BFFF", hover_color="#009ACD",
                  corner_radius=12, font=("Segoe UI", 14, "bold"),
                  command=connect_arduino).grid(row=0, column=1, padx=10, pady=10)

    ctk.CTkButton(port_frame, text="Disconnect", fg_color="red", hover_color="#8B0000",
                  corner_radius=12, font=("Segoe UI", 14, "bold"),
                  command=disconnect_arduino).grid(row=0, column=2, padx=10, pady=10)

    # Status
    status_var = ctk.StringVar(value="❌ Disconnected")
    ctk.CTkLabel(port_frame, textvariable=status_var,
                 font=("Segoe UI", 14, "bold"),
                 text_color="gray").grid(row=0, column=3, padx=20, pady=10, sticky="w")

    # Threshold Frame
    threshold_frame = ctk.CTkFrame(root, corner_radius=15, fg_color="#2e2e2e")
    threshold_frame.pack(pady=10, padx=20, fill="x")

    ctk.CTkLabel(threshold_frame, text="Min Distance (cm):", font=("Segoe UI", 14), text_color="white").grid(row=0, column=0, padx=10, pady=10)
    min_entry = ctk.CTkEntry(threshold_frame, width=80, font=("Segoe UI", 14))
    min_entry.insert(0, "10")
    min_entry.grid(row=0, column=1, padx=10)

    ctk.CTkLabel(threshold_frame, text="Max Distance (cm):", font=("Segoe UI", 14), text_color="white").grid(row=0, column=2, padx=10, pady=10)
    max_entry = ctk.CTkEntry(threshold_frame, width=80, font=("Segoe UI", 14))
    max_entry.insert(0, "100")
    max_entry.grid(row=0, column=3, padx=10)

    # Graph
    graph_frame = ctk.CTkFrame(root, corner_radius=15, fg_color="#2e2e2e")
    graph_frame.pack(pady=10, padx=20, fill="both", expand=True)

    fig, ax = plt.subplots(figsize=(6, 3))
    canvas = FigureCanvasTkAgg(fig, master=graph_frame)
    canvas.get_tk_widget().pack(fill="both", expand=True)

    # Buttons
    button_frame = ctk.CTkFrame(root, corner_radius=15, fg_color="#2e2e2e")
    button_frame.pack(pady=10, padx=20, fill="x")

    ctk.CTkButton(button_frame, text="💾 Save Data", fg_color="green", hover_color="#006400",
                  corner_radius=15, font=("Segoe UI", 14, "bold"),
                  command=save_data).pack(side="left", padx=20, pady=10)

    ctk.CTkButton(button_frame, text="🔄 Refresh", fg_color="orange", hover_color="#cc8400",
                  corner_radius=15, font=("Segoe UI", 14, "bold"),
                  command=refresh_graph).pack(side="left", padx=20, pady=10)

    # Exit Button
    nav_frame = ctk.CTkFrame(root, corner_radius=15, fg_color="#2e2e2e")
    nav_frame.pack(pady=10, padx=20, fill="x")

    ctk.CTkButton(nav_frame, text="Exit", fg_color="red", hover_color="#8B0000",
                  corner_radius=15, font=("Segoe UI", 14, "bold"),
                  command=root.quit).pack(pady=10)

    root.mainloop()


# ------------------------------
# Protect standalone run
# ------------------------------
if __name__ == "__main__":
    if auth.AUTHORIZED:
        run_distance_calculator()
    else:
        import login
        login.open_login()
