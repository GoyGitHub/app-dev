import serial
import os

# change port to your Arduino's port (check Arduino IDE -> Tools -> Port)
arduino = serial.Serial('/dev/cu.usbserial-1420', 9600)

while True:
    try:
        data = arduino.readline().decode().strip()
        if data.isdigit():
            temp = int(data)
            print(f"Temp: {temp} °C")
            if temp >= 32:
                # Mac beep sound
                os.system('say "Warning temperature high"')  # macOS voice alert
                os.system('afplay /System/Library/Sounds/Glass.aiff')  # macOS system sound
    except:
        pass
