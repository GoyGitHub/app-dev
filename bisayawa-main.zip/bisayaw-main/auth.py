# auth.py
AUTHORIZED = False
