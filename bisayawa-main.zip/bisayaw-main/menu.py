import customtkinter as ctk
import auth
from utils import safe_destroy

def open_tms_app(prev_window):
    prev_window.destroy()
    import tms_app
    tms_app.run_tms_app()

def open_temperature_humidity_app(prev_window):
    prev_window.destroy()
    import temperature_humidity_app
    temperature_humidity_app.run_temperature_humidity_app()

def open_main_menu():
    # ✅ enforce login
    if not auth.AUTHORIZED:
        import login
        login.open_login()
        return

    menu_window = ctk.CTk()
    menu_window.title("Main Menu")
    menu_window.geometry("420x600")
    menu_window.configure(fg_color="#1a1a1a")

    cooper_font_large = ("Cooper Black", 26)
    cooper_font_medium = ("Cooper Black", 15)

    ctk.CTkLabel(menu_window,
                 text="MAIN MENU",
                 font=cooper_font_large,
                 text_color="white").pack(pady=30)

    buttons = [
        ("TMS APPLICATION", lambda: open_tms_app(menu_window)),
        ("HUMIDITY & TEMPERATURE", lambda: open_temperature_humidity_app(menu_window)),
        ("LOCK / UNLOCK SYSTEM", None),
        ("ITEM DETECTOR SYSTEM", None),
        ("DISTANCE MEASURE SYSTEM", None)
    ]

    for text, command in buttons:
        ctk.CTkButton(menu_window,
                      text=text,
                      font=cooper_font_medium,
                      width=280,
                      height=55,
                      corner_radius=18,
                      fg_color="#00BFFF",
                      hover_color="#009ACD",
                      text_color="black",
                      command=command).pack(pady=12)

    def logout():
        import login
        auth.AUTHORIZED = False
        menu_window.quit()  # ✅ stop loop
        safe_destroy(menu_window)
        login.open_login()

    def close_app():
        menu_window.quit()  # ✅ stop loop
        safe_destroy(menu_window)

    ctk.CTkButton(menu_window,
                  text="LOGOUT",
                  font=cooper_font_medium,
                  width=280,
                  height=50,
                  corner_radius=18,
                  fg_color="orange",
                  hover_color="#cc8400",
                  text_color="white",
                  command=logout).pack(pady=12)

    ctk.CTkButton(menu_window,
                  text="EXIT",
                  font=cooper_font_medium,
                  width=280,
                  height=50,
                  corner_radius=18,
                  fg_color="red",
                  hover_color="#8B0000",
                  text_color="white",
                  command=close_app).pack(pady=25)

    menu_window.mainloop()


# ✅ Protect standalone run
if __name__ == "__main__":
    if auth.AUTHORIZED:
        open_main_menu()
    else:
        import login
        login.open_login()
