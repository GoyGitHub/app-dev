import auth
import login
import menu

if __name__ == "__main__":
    if auth.AUTHORIZED:
        menu.open_main_menu()
    else:
        login.open_login()
