import tkinter as tk
from tkinter import ttk, messagebox
import time
import threading
import serial
import sys
import subprocess
from serial.tools import list_ports
import pyttsx3
import menu  # Import menu so we can go back
import auth
from utils import safe_destroy   # ✅ add this

# ========================
# VOICE ALERT
# ========================
def speak_alert_continuous(state):
    """Continuously speak while the alert is active."""
    while state["running"]:
        if state["alert_active"]:
            engine = pyttsx3.init()
            engine.setProperty('rate', 160)
            engine.say("Warning! High temperature alert.")
            engine.runAndWait()
            engine.stop()
            time.sleep(0.1)
        else:
            time.sleep(0.2)

# ========================
# BEEP ALERT
# ========================
try:
    import winsound
    def beep(freq, dur):
        try:
            winsound.Beep(freq, dur)
        except Exception:
            pass
except ImportError:
    def beep(freq, dur):
        try:
            if sys.platform == "darwin":
                subprocess.Popen(
                    ["afplay", "/System/Library/Sounds/Ping.aiff"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                )
            else:
                print("\a", end="", flush=True)
        except Exception:
            pass

def beeping_loop(state):
    """Continuously beep while alert is active."""
    while state["running"]:
        if state["alert_active"]:
            beep(800, 300)
            time.sleep(1)
        else:
            time.sleep(0.2)

# ========================
# SERIAL PORT DETECTION
# ========================
def guess_best_port(port_list):
    low = [p.lower() for p in port_list]
    mac = [p for p, l in zip(port_list, low)
           if "/cu." in l and any(k in l for k in ("usbmodem", "usbserial", "wchusbserial"))]
    if mac:
        return mac[0]
    usb = [p for p, l in zip(port_list, low)
           if any(k in l for k in ("usbmodem", "usbserial", "wchusbserial"))]
    if usb:
        return usb[0]
    if sys.platform.startswith("win") and any(p.upper() == "COM3" for p in port_list):
        return "COM3"
    return port_list[0] if port_list else None

# ========================
# COMPUTE HEAT INDEX (Celsius)
# ========================
def compute_heat_index(temp, humid):
    """Compute heat index in Celsius given temp (°C) and humidity (%)"""
    if temp is None or humid is None:
        return 0.0
    try:
        # Convert to Fahrenheit for formula
        T = temp * 9/5 + 32
        R = humid
        HI = (
            -42.379 + 2.04901523*T + 10.14333127*R
            - 0.22475541*T*R - 6.83783e-3*T*T
            - 5.481717e-2*R*R + 1.22874e-3*T*T*R
            + 8.5282e-4*T*R*R - 1.99e-6*T*T*R*R
        )
        # Back to Celsius
        return round((HI - 32) * 5/9, 1)
    except Exception:
        return 0.0

# ========================
# MAIN APP
# ========================
def run_temperature_humidity_app():
    # Detect serial ports
    ports = [p.device for p in list_ports.comports()]
    if not ports:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("🌡️ Temperature & Humidity Monitor",
                             "No serial ports found. Please connect your Arduino and try again.")
        r.destroy()
        return

    selected_port = guess_best_port(ports) or ports[0]

    try:
        arduino = serial.Serial(port=selected_port, baudrate=9600, timeout=1)
    except Exception as e:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("🌡️ Temperature & Humidity Monitor", f"Serial Error: {e}")
        r.destroy()
        return

    time.sleep(2)
    try:
        arduino.reset_input_buffer()
    except Exception:
        pass

    # ========================
    # APP STATE
    # ========================
    state = {
        "running": True,
        "temperature": 0,
        "humidity": 0,
        "alert_active": False,
        "alert_threshold": 32,  # Default threshold
    }

    root = tk.Tk()
    root.title("🌡️ Temperature & Humidity Monitor")
    root.configure(bg="#1a1a1a")

    # ====== DARK MODE ======
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("Primary.TButton", background="#00BFFF", foreground="white", padding=(8, 6))
    style.map("Primary.TButton", background=[("active", "#009ACD")])

    def ui_call(fn, *args, **kwargs):
        try:
            root.after(0, lambda: fn(*args, **kwargs))
        except Exception:
            pass

    # ====== GUI ======
    frame = tk.Frame(root, bg="#1a1a1a", padx=20, pady=20)
    frame.pack(fill="both", expand=True)

    # ---- Back Button in Upper-Left ----
    def go_back():
        state["running"] = False
        try:
            arduino.close()
        except Exception:
            pass
        safe_destroy(root)  # ✅ instead of root.destroy()
        menu.open_main_menu()

    back_button = tk.Button(root,
                            text="← Back",
                            command=go_back,
                            font=("Cooper Black", 12),
                            bg="#00BFFF",
                            fg="black",
                            activebackground="#009ACD",
                            relief=tk.FLAT)
    back_button.place(x=10, y=10)  # Top-left corner

    # ---- Title ----
    tk.Label(frame,
             text="Temperature & Humidity Monitor",
             font=("Cooper Black", 18),
             fg="white",
             bg="#1a1a1a").pack(pady=(40, 15))

    # ---- ALERT DISPLAY ABOVE TEMP ----
    alert_label = tk.Label(frame,
                           text="NORMAL",
                           font=("Cooper Black", 30, "bold"),
                           fg="green",
                           bg="#1a1a1a")
    alert_label.pack(pady=15)

    # ---- Temperature, Humidity, Heat Index ----
    temp_frame = tk.Frame(frame, bd=2, relief=tk.RIDGE, padx=15, pady=15, bg="#2e2e2e")
    temp_frame.pack(padx=10, pady=10, fill="x")

    tk.Label(temp_frame, text="Temperature:",
             font=("Cooper Black", 14), fg="white", bg="#2e2e2e").grid(row=0, column=0, padx=10, pady=5, sticky="w")

    temp_value = tk.Label(temp_frame, text="-- °C",
                          font=("Cooper Black", 26, "bold"),
                          fg="#FF5733", bg="#2e2e2e")
    temp_value.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(temp_frame, text="Humidity:",
             font=("Cooper Black", 14), fg="white", bg="#2e2e2e").grid(row=1, column=0, padx=10, pady=5, sticky="w")

    humid_value = tk.Label(temp_frame, text="-- %",
                           font=("Cooper Black", 26, "bold"),
                           fg="#00BFFF", bg="#2e2e2e")
    humid_value.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(temp_frame, text="Heat Index:",
             font=("Cooper Black", 14), fg="white", bg="#2e2e2e").grid(row=2, column=0, padx=10, pady=5, sticky="w")

    hi_value = tk.Label(temp_frame, text="-- °C",
                        font=("Cooper Black", 26, "bold"),
                        fg="#FFA500", bg="#2e2e2e")
    hi_value.grid(row=2, column=1, padx=10, pady=5)

    # ---- Threshold Section ----
    threshold_frame = tk.Frame(frame, bd=2, relief=tk.RIDGE, padx=15, pady=15, bg="#2e2e2e")
    threshold_frame.pack(padx=10, pady=10, fill="x")

    tk.Label(threshold_frame, text="Temperature Alert Threshold:",
             font=("Cooper Black", 12), fg="white", bg="#2e2e2e").grid(row=0, column=0, padx=5, pady=5, sticky="w")

    threshold_var = tk.StringVar(value=str(state["alert_threshold"]))
    threshold_entry = tk.Entry(threshold_frame, textvariable=threshold_var,
                               width=5, font=("Cooper Black", 12),
                               bg="#1a1a1a", fg="white", insertbackground="white")
    threshold_entry.grid(row=0, column=1, padx=5, pady=5)

    tk.Label(threshold_frame, text="°C",
             font=("Cooper Black", 12), fg="white", bg="#2e2e2e").grid(row=0, column=2, padx=5, pady=5, sticky="w")

    def update_threshold():
        try:
            new_threshold = float(threshold_var.get())
            state["alert_threshold"] = new_threshold
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid number for threshold.")

    ttk.Button(threshold_frame, text="Update",
               style="Primary.TButton",
               command=update_threshold).grid(row=0, column=3, padx=10, pady=5)

    # ====== ALERT SYSTEM ======
    def update_alert_status(is_alert):
        if is_alert and not state["alert_active"]:
            state["alert_active"] = True
            ui_call(alert_label.config, text="⚠️ HIGH TEMPERATURE ALERT ⚠️", fg="red")
        elif not is_alert and state["alert_active"]:
            state["alert_active"] = False
            ui_call(alert_label.config, text="NORMAL", fg="green")

    # ====== Update Display ======
    def update_temperature_display(temp, humid):
        ui_call(temp_value.config, text=f"{temp:.1f} °C")
        ui_call(humid_value.config, text=f"{humid:.1f} %")

        # Compute HI and update GUI
        hi = compute_heat_index(temp, humid)
        ui_call(hi_value.config, text=f"{hi:.1f} °C")

        if temp >= state["alert_threshold"]:
            update_alert_status(True)
        else:
            update_alert_status(False)

    # ====== Arduino Reading ======
    def read_arduino_data():
        while state["running"]:
            try:
                if arduino.in_waiting > 0:
                    line = arduino.readline().decode(errors='ignore').strip()
                    print("Arduino:", line)

                    if "Humidity:" in line and "Temp:" in line:
                        parts = line.split()
                        for i, part in enumerate(parts):
                            if part == "Humidity:":
                                try:
                                    state["humidity"] = float(parts[i + 1])
                                except (ValueError, IndexError):
                                    pass
                            elif part == "Temp:":
                                try:
                                    state["temperature"] = float(parts[i + 1])
                                except (ValueError, IndexError):
                                    pass

                        update_temperature_display(state["temperature"], state["humidity"])
            except Exception:
                pass
            time.sleep(0.5)

    # ====== Start Threads ======
    threading.Thread(target=speak_alert_continuous, args=(state,), daemon=True).start()
    threading.Thread(target=beeping_loop, args=(state,), daemon=True).start()
    threading.Thread(target=read_arduino_data, daemon=True).start()

    root.mainloop()

    # after root.mainloop()
    state["running"] = False
    try:
        arduino.close()
    except Exception:
        pass
    safe_destroy(root)  # ✅ just to be safe

# ========================
# RUN APP
# ========================
if __name__ == "__main__":
    if auth.AUTHORIZED:
        run_temperature_humidity_app()
    else:
        import login
        login.open_login()
